<?php
    echo 'My IP : '.$_SERVER['REMOTE_ADDR'];
?>