<?php?>

<div id="ip-ku"></div>

<script src="./jquery.min.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">

var timeout = setInterval(reload, 0800);
function reload () {
     $("#ip-ku").load("cek-ip.php");
}
</script>